# -*- coding: UTF-8 -*-

from .meshpartitioning  import MeshPartition
