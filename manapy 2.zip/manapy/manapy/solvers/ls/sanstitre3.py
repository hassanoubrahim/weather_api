import numpy as np
import ls_mumps
from scipy.sparse import coo_matrix, csr_matrix
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve


'''
a = [[ 2.  3.  4.  0.  0.]
[ 3.  0. -3.  0.  6.]
[ 0. -1.  1.  2.  0.]
[ 0.  0.  2.  0.  0.]
[ 0.  4.  0.  0.  1.]]
'''
from mpi4py import MPI
comm = MPI.COMM_WORLD
rank = comm.Get_rank()

#A = np.array([[3.0, 4.0], [2.0, 1.0]])
#b = np.array([[1.0, -1.0], [1.0, -1.0]])



A = np.loadtxt('A1.txt')
R = np.loadtxt('R1.txt')#[::,0:2]
#R = np.zeros_like(B)
#R[0][0]=1
#B = R.copy()
    

AR2 = spsolve(csr_matrix(A), R)
print(AR2)

#mumps_ls = mumps.MumpsSolver(system="real")

#row, col = A.nonzero()
#data = A[(row, col)]

def get_non_zero_columns(matrix):
    # Trouvez les indices des colonnes qui ne sont pas entièrement nulles
    non_zero_columns = np.where(np.any(matrix != 0, axis=0))[0]

    # Renvoyez une nouvelle matrice contenant uniquement les colonnes non nulles
    return matrix[:, non_zero_columns]

Rbis = get_non_zero_columns(R)

def solve_mumps(A, R):
    ctx = ls_mumps.MumpsSolver(is_sym=0, silent=True, mpi_comm=comm)
    ctx.struct.par = 0
    A = coo_matrix(A)
    ctx.set_mtx_centralized(A)
    ctx.struct.n = A.shape[0]
    AR = R.T.copy().astype(np.double)
    ctx._mumps_call(job=1)
    #Factorization Phase
    ctx._mumps_call(job=2)
    
    ctx.set_rhs(AR)
    ctx._mumps_call(job=3)
    ctx.__del__()
    
    return AR
#ctx.set_rcd_centralized(row+1, col+1, data, A.shape[0])
#ctx.set_verbose()
#ctx.set_rcd_distributed(row+1, col+1, data.astype(np.float64))
#ctx.set_icntl(24, 1)
#ctx.set_icntl(14, 50)

#ctx.set_icntl(18,3)

AR = np.zeros_like(R.T)
#ARbis = solve_mumps(A,Rbis)
    
#AR[R.shape[1] - R.shape[0]:,::] = solve_mumps(A,Rbis)
AR[:R.shape[0],::] = solve_mumps(A,Rbis)

assert np.allclose(AR.T, AR2, rtol=1e-14, atol=1e-14)


ctx = ls_mumps.MumpsSolver(is_sym=0, silent=False, mpi_comm=comm)
ctx.struct.par = 0
# Set up the test problem:
n = 5
irn = np.array([0,1,3,4,1,0,4,2,1,2,0,2], dtype='i')
jcn = np.array([1,2,2,4,0,0,1,3,4,1,2,2], dtype='i')
a = np.array([3.0,-3.0,2.0,1.0,3.0,2.0,4.0,2.0,6.0,-1.0,4.0,1.0], dtype='d')
#
b = np.array([[20.0,24.0,9.0,6.0,13.0], [20.0,24.0,9.0,6.0,13.0], [20.0,24.0,9.0,6.0,13.0],
              [20.0,24.0,9.0,6.0,13.0], [20.0,24.0,9.0,6.0,13.0], [20.0,24.0,9.0,6.0,13.0] ], dtype='d')
    
b = np.zeros((6, 5))
#b = np.array([[20., 24.,  9.,  6., 13.],
#       [20., 24.,  9.,  6., 13.],
#       [20., 24.,  9.,  6., 13.]])
# Create the MUMPS context and set the array and right hand side

ctx.set_shape(n)
ctx.set_rcd_centralized(irn+1, jcn+1, a, n)
#ctx.set_mtx_centralized(coo_matrix(A))
x = b.copy()
ctx.set_rhs(x)

#ctx.struct.nrhs = 3
#ctx.struct.lrhs = 3*n

    #ctx.set_silent() # Turn off verbose output
ctx._mumps_call(job=6)
#ctx._mumps_call(job=2)
#ctx._mumps_call(job=3)


#if ctx.myid == 0:
print("Solution is %s." % (x.T,))

ctx.__del__() # Free memory
