# -*- coding: UTF-8 -*-

from manapy.solvers.ls.system import MUMPSSolver, PETScKrylovSolver, ScipySolver

