# -*- coding: utf-8 -*-
#from manapy.backends.base import Backend
#from manapy.utils.misc import subclass_by_name

from manapy.backends.cpu.backend import CPUBackend
#def get_backend(name, *args, **kwargs):
#    print(Backend.name, name)
#    return subclass_by_name(Backend, name)#(*args, **kwargs)
