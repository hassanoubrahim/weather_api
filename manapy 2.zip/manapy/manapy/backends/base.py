# -*- coding: utf-8 -*-


class Backend:
    #TODO: Just abstract class, will improve if other hardawer backend is developed
    name = 'base'
    